﻿using System;
using System.Threading;
using IntegralLib;

namespace _053502_Yurev_Lab11
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Clear();
            
            IntegralComputing integral = new IntegralComputing();

            integral.enterPress += integral.DisplayMessage;
            
            Thread thread1 = new Thread(integral.Computing);
            Thread thread2 = new Thread((integral.Computing));
            
            thread1.Priority = ThreadPriority.Highest;
            thread2.Priority = ThreadPriority.Lowest;
           
            thread1.Start();
            thread2.Start();

            Console.WriteLine("Press enter to compute the integral.");
            while(thread2.IsAlive)
            {
                if (Console.ReadKey().Key == ConsoleKey.Enter)
                {
                    integral.GetCurrentProgress();
                }
            }
            
            Console.WriteLine("Press spacebar to end the program...");
            
            while (Console.ReadKey().Key != ConsoleKey.Spacebar)
            {
                
            }

            integral.enterPress -= integral.DisplayMessage;
        }
    }
}